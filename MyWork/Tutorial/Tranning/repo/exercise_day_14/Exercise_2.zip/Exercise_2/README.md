ruby handle.rb to run exercise
