ruby main.rb to run exercise
